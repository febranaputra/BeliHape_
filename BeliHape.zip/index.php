<?php
include 'connection.php';
session_start();
$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_GET['logout'])){
   unset($user_id);
   session_destroy();
   header('location:login.php');
};

if(isset($_POST['add_to_cart'])){
   $product_nama = $_POST['nama_produk'];
   $product_harga= $_POST['harga'];
   $product_image = $_POST['gambar'];
   $product_quantity = isset($_POST['jumlah']) ? $_POST['jumlah'] : 1;

   $select_cart = mysqli_query($con, "SELECT * FROM `keranjang` WHERE nama_produk = '$product_nama' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'produk sudah ada di!';
   }else{
      mysqli_query($con, "INSERT INTO `keranjang`(user_id, nama_produk, harga, gambar, jumlah) VALUES('$user_id', '$product_nama', '$product_harga', '$product_image', '$product_quantity')") or die('query failed');
      $message[] = 'produk telah ditambahkan ke keranjang!';
   }
};

if(isset($_POST['update_cart'])){
   $update_quantity = isset($_POST['jumlah']) ? $_POST['jumlah'] : 1;
   $update_id = $_POST['keranjang_id'];
   mysqli_query($con, "UPDATE `keranjang` SET jumlah = '$update_quantity' WHERE id = '$update_id'") or die('query failed');
   $message[] = 'update keranjang sukses!';
}

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($con, "DELETE FROM `keranjang` WHERE id = '$remove_id'") or die('query failed');
   header('location:index.php');
}
  
if(isset($_GET['delete_all'])){
   mysqli_query($con, "DELETE FROM `keranjang` WHERE user_id = '$user_id'") or die('query failed');
   header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beli HP Murah & Berkualitas - BeliHape</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/keranjang.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="icon" href="youtube logo.png">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li class="home"><a href="#">Beranda</a></li>
                <li><a href="#">Gabung mitra</a></li>
                <li><a href="#">Karir</a></li>
                <li><a href="#">Perusahaan</a></li>
                <li><a href="#">Produk</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
        </nav>
    </header>
    <main>
            <video autoplay muted loop id="myVideo">
            <source src="video/y2mate.com - Gojek  The Flow_1080p.mp4" type="video/mp4">
          </video>

    
        <div class="tampilan-awal">
        <h2>3 negara.</h2>
        <h2>20+ produk.</h2>
        
        <h2>1 platform <span class="ondemand">on-demand</span> terkemuka.</h2>
    </div>

    
    <section class="background2">
    <div class="perkenalan">
    <h2>Kenalin, BeliHape. <span class="ondemand">Si paling berkualitas</span></h2>
     <!-- pang dinamis -->
    <h3><?php echo date("d F Y"); ?></h3>

    <!-- if sederhana -->
    <!-- untuk meraup uang customer sebanyak2nya -->
    <!-- makin besar, makin dikit untungnya (hanya owner yg tau kenapa codenya spt ini) -->
<!-- <?php
    $nilai_untung = 30;
    $hari = "Sabtu";

if ($nilai_untung >= 70) {
    echo "Jangan beli dulu.<br>";
} elseif ($nilai_untung >= 50) {
    echo "DISKON 30% CUY<br>";
} else {
    echo "Anda harus beli!<br>";
}

switch ($hari) {
    case "Sabtu":
    case "Minggu":
        echo "Hari libur.<br>";
        break;
    default:
        echo "Hari kerja<br>";
}
?>

 -->
 <?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}
?>

<div class="container">

<!-- user profile -->
<div class="user-profile">

   <?php
      $select_user = mysqli_query($con, "SELECT * FROM `user` WHERE user_id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_user) > 0){
         $fetch_user = mysqli_fetch_assoc($select_user);
      };
   ?>

   <p> username : <span><?php echo $fetch_user['nama']; ?></span> </p>
   <p> email : <span><?php echo $fetch_user['email']; ?></span> </p>
   <div class="flex">
      <a href="login.php" class="btn">login</a>
      <a href="register.php" class="option-btn">register</a>
      <a href="index.php?logout=<?php echo $user_id; ?>" onclick="return confirm('are your sure you want to logout?');" class="delete-btn">logout</a>
   </div>
   </div>


<!-- produk -->
<div class="produk">

  <br> <br>
  <div class="box-container">
      <?php
      include "connection.php";
      $que    = "SELECT * FROM produk";
      $select = mysqli_query($con, $que);

      while ($data = mysqli_fetch_array($select)) {
      ?>
        <form method="post" class="box" action="">
          <img src="img/<?php echo $data['gambar']; ?>" alt="">
          <div  class="nama-produk"><?php echo $data['nama_produk'];?> </div>
          <div class="harga">Rp<?php echo $data['harga'];?> </div>
          <input style="color: black;" type="number" min="1" name="jumlah" value="">
          <input type="hidden" name="gambar" value="<?php echo $data['gambar']; ?>">
          <input type="hidden" name="nama_produk" value="<?php echo $data['nama_produk']; ?>">
          <input type="hidden" name="harga" value="<?php echo $data['harga']; ?>">
          <input type="submit" value="Masukan Keranjang" name="add_to_cart" class="btn">
        </form>
      <?php
      };
      ?>
    </div>
</div>


<br>
<br>
<!-- keranjang -->
<div class="shopping-cart">

   <h1 class="heading">Keranjang</h1>
   <br>
   <table>
      <thead>
         <th></th>
         <th>Nama</th>
         <th>Harga</th>
         <th>Jumlah</th>
         <th>Total Harga</th>
         <th>Aksi</th>
      </thead>
      <tbody>
      <?php
        $cart_query = mysqli_query($con, "SELECT * FROM `keranjang` WHERE user_id = '$user_id'") or die('query failed');
         $grand_total = 0;
         
         if(mysqli_num_rows($cart_query) > 0){
            while($keranjang = mysqli_fetch_assoc($cart_query)){
      ?>
         <tr>
            <td><img src="img/<?php echo $keranjang['gambar']; ?>" height="100" alt=""></td>
            <td><?php echo $keranjang['nama_produk']; ?></td>
            <td>Rp<?php echo $keranjang['harga']; ?>/-</td>
            <td>
               <form action="" method="post">
               <input style="color: black;" type="number" min="1" name="jumlah" value="<?php echo $keranjang['jumlah']; ?>">
               <input type="hidden" name="keranjang_id" value="<?php echo $keranjang['id']; ?>">
               <input style="color: black;" type="submit" name="update_cart" value="update" class="option-btn">
               </form>
            </td>
            <td>Rp<?php echo $sub_total = (intval($keranjang['harga']) * intval($keranjang['jumlah'])); ?></td>
            <td><a href="index.php?remove=<?php echo $keranjang['id']; ?>" class="delete-btn" onclick="return confirm('remove item from cart?');">remove</a></td>
         </tr>
      <?php
         $grand_total += $sub_total;
            }
         }else{
            echo '<tr><td style="padding:20px; text-transform:capitalize;" colspan="6">no item added</td></tr>';
         }
      ?>
      <tr class="table-bottom">
         <td colspan="4">Total :</td>
         <td>Rp<?php echo $grand_total; ?>/-</td>
         <td><a href="index.php?delete_all" onclick="return confirm('delete all from cart?');" class="delete-btn <?php echo ($grand_total > 1)?'':'disabled'; ?>">delete all</a></td>
      </tr>
   </tbody>
   </table>

   <div class="cart-btn">  
      <a href="#" class="btn <?php echo ($grand_total > 1)?'':'disabled'; ?>">gas checkout</a>
   </div>

</div>
</div>

<!-- footer -->
        </div>
        <section class="banyak-orang">
        <h2 class="judulscale">We scale like a dream</h2>
        <div class="scale-with-us"><a href="https://wa.me/0895342586112"target="_blank">Scale with us</a></div>
  
<section class="kumpulankotak">
        <div class="kotak1">

            <div class="isikotak1"><img data-src="https://lelogama.go-jek.com/prime/upload/image/170_mil.png" alt="Gojek" class="c-feature-card-spot-brand__image lazy w-full entered loaded" width="300px" height="200px" data-ll-status="loaded" src="https://lelogama.go-jek.com/prime/upload/image/170_mil.png">
            <p class="juta">190 Juta+</p>
            <p class="download">orang indonesia terhubung</p>
        </div>

           
        </div>

        <div class="kotak2">
            <div class="isikotak2"><img data-src="https://lelogama.go-jek.com/prime/upload/image/2_million.png" alt="Gojek" class="c-feature-card-spot-brand__image lazy w-full entered loaded" width="300px" height="200px" data-ll-status="loaded" src="https://lelogama.go-jek.com/prime/upload/image/2_million.png">
            <p class="juta2">2 Juta+</p>
            <p class="download2">karyawan siap mengantar</p>
        </div>
         
        </div>

        <div class="kotak3">
            <div class="isikotak3"><img data-src="https://lelogama.go-jek.com/prime/upload/image/50_million.png" alt="Gojek" class="c-feature-card-spot-brand__image lazy w-full entered loaded" width="300px" height="200px" data-ll-status="loaded" src="https://lelogama.go-jek.com/prime/upload/image/50_million.png">
            <p class="juta3">900,000+</p>
            <p class="download3">charity food</p>
        </div>
            
        </div>

        <div class="kotak4">
            <div class="isikotak4"><img data-src="https://lelogama.go-jek.com/prime/upload/image/12x_growth.png" alt="Gojek" class="c-feature-card-spot-brand__image lazy w-full entered loaded" width="300px" height="200px" data-ll-status="loaded" src="https://lelogama.go-jek.com/prime/upload/image/12x_growth.png">
            <p class="juta4">2.448x</p>
            <p class="download4">kunjungan website sehari</p>
        </div>
            
        </div>
        </section>


</section>
    </main>
</body>
</html>
