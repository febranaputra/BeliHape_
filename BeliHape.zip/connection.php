<?php

	$server		= "localhost"; 
	$user		= "root";
	$password	= ""; 
	$database	= "belihape"; 

	$con = mysqli_connect($server,$user,$password,$database);

?>
